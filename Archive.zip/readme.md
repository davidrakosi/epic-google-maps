A feltöltött a Google Maps API le van korlatozva erre a weboldalra: 
https://drakosi99.github.io/epic-google-maps-project/

A weboldal pedig a feltöltött fileokat használja.